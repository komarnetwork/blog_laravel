<?php

namespace App\Http\Livewire;


use App\Pesanan;
use App\Product;
use App\PesananDetail;
use Livewire\Component;
use Illuminate\Support\Facades\Auth;

class Keranjang extends Component
{
    public $product, $nama, $harga;

    protected $pesanan;
    protected $pesanan_details = [];


    // Delete
    public function destroy($id)
    {
        $pesanan_detail = PesananDetail::find($id);
        if (!empty($pesanan_detail)) {

            $pesanan = Pesanan::where('id', $pesanan_detail->pesanan_id)->first();
            $jumlah_pesanan_detail = PesananDetail::where('pesanan_id', $pesanan->id)->count();
            if ($jumlah_pesanan_detail == 1) {
                $pesanan->delete();
            } else {
                $pesanan->total_harga = $pesanan->total_harga - $pesanan_detail->total_harga;
                $pesanan->update();
            }

            $pesanan_detail->delete();
        }

        $this->emit('masukKeranjang');
        // alert()->success('Title','Lorem Lorem Lorem');

        session()->flash('message', 'Pesanan Dihapus');

    }

    // WA
    public function masukkanWa()
    {
        $this->emit('masukkanWa');
    }

    // index
    public function render()
    {
        if (Auth::user()) {
            $this->pesanan = Pesanan::where('user_id', Auth::user()->id)->where('status', 0)->first();
            if ($this->pesanan) {
                $this->pesanan_details = PesananDetail::where('pesanan_id', $this->pesanan->id)->get();
            }
           
        }

        return view('livewire.keranjang', [
            'pesanan' => $this->pesanan,
            'pesanan_details' => $this->pesanan_details,
            'products' => Product::all()
        ]);
    }
}
