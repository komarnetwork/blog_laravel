<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Auth::routes();

Route::livewire('/', 'home')->name('home');
// page bunga/product

Route::middleware(['web',])->group(function () {
    Route::livewire('/products', 'product-index')->name('products');
    Route::livewire('/products/{slug}', 'product-liga')->name('products.liga');
    Route::livewire('/products/detail/{slug}', 'product-detail')->name('products.detail');
    // page parcel

    Route::livewire('/keranjang', 'keranjang')->name('keranjang');
});

// Route::livewire('/checkout', 'checkout')->name('checkout');
// Route::livewire('/history', 'history')->name('history');


Route::middleware('auth')->group(function () {
    Route::livewire('/history', 'history')
        ->name('history');

    Route::livewire('/checkout', 'checkout')
    ->name('checkout');
});
