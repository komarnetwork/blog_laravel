;(function($, window, document){
	'use strict';

	$( '#cartzilla-related-posts' ).selectize( {
		plugins: ['drag_drop', 'remove_button'],
	} );

})(jQuery, window, document);
