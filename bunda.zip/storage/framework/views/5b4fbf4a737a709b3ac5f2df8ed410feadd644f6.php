<div>
   <!-- Sign in / sign up modal-->
   <div class="modal fade" id="signin-modal" tabindex="-1" role="dialog">
      <div class="modal-dialog modal-dialog-centered" role="document">
         <div class="modal-content">
            <div class="modal-header bg-secondary">
               <ul class="nav nav-tabs card-header-tabs" role="tablist">
                  <li class="nav-item"><a class="nav-link fw-medium active" href="#signin-tab" data-bs-toggle="tab" role="tab" aria-selected="true"><i class="ci-unlocked me-2 mt-n1"></i><?php echo e(__('Login')); ?></a></li>
                  <li class="nav-item"><a class="nav-link fw-medium" href="#signup-tab" data-bs-toggle="tab" role="tab" aria-selected="false"><i class="ci-user me-2 mt-n1"></i><?php echo e(__('Register')); ?></a></li>
               </ul>
               <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body tab-content py-4">
               <form method="POST" action="<?php echo e(route('login')); ?>" class="needs-validation tab-pane fade show active" autocomplete="off" novalidate id="signin-tab">
                  <?php echo csrf_field(); ?>
                  <div class="mb-3">
                     <label class="form-label" for="email"><?php echo e(__('E-Mail Address')); ?></label>
                     <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email" type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="cs@bundaflorist.id" required autocomplete="email" autofocus>
                     <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <div class="invalid-feedback">Harap Masukkan Email Yang Valid.</div>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="mb-3">
                     <label class="form-label" for="password"><?php echo e(__('Password')); ?></label>
                     <div class="password-toggle">
                        <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" name="password" required autocomplete="current-password">
                        <label class="password-toggle-btn" aria-label="Show/hide password">
                           <input class="password-toggle-check" type="checkbox">
                           
                           <span class="password-toggle-indicator"></span>
                           
                        </label>
                     </div>
                  </div>

                  <div class="mb-3 d-flex flex-wrap justify-content-between">
                     <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="remember"><?php echo e(__('Remember Me')); ?></label>
                     </div>

                     <?php if(Route::has('password.request')): ?>
                     <a class="fs-sm" href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Forgot Your Password?')); ?></a>
                     <?php endif; ?>
                  </div>

                  <button class="btn btn-primary btn-shadow d-block w-100" type="submit"><?php echo e(__('Login')); ?></button>
               </form>

               <form method="POST" action="<?php echo e(route('register')); ?>" class="needs-validation tab-pane fade" autocomplete="off" novalidate id="signup-tab">
                  <?php echo csrf_field(); ?>

                  <div class="mb-3">
                     <label class="form-label" for="su-name"><?php echo e(__('Name')); ?></label>
                     <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" placeholder="John Doe" required autocomplete="name" autofocus>
                     <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <div class="invalid-feedback">Harap Masukkan Nama Anda.</div>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="mb-3">
                     <label for="email"><?php echo e(__('E-Mail Address')); ?></label>
                     <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="cs@bundaflorist.id" required autocomplete="email">
                     <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <div class="invalid-feedback">Please provide a valid email address.</div>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="mb-3">
                     <label class="form-label" for="password"><?php echo e(__('Password')); ?></label>
                     <div class="password-toggle">
                        <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" name="password" required autocomplete="new-password">
                        <label class="password-toggle-btn" aria-label="Show/hide password">
                           <input class="password-toggle-check" type="checkbox">
                           
                           <span class="password-toggle-indicator"></span>
                           
                        </label>
                     </div>
                  </div>
                  <div class="mb-3">
                     <label class="form-label" for="password-confirm"><?php echo e(__('Confirm Password')); ?></label>
                     <div class="password-toggle">
                        <input class="form-control" type="password" id="password-confirm" name="password_confirmation" required autocomplete="new-password">
                        <label class="password-toggle-btn" aria-label="Show/hide password">
                           <input class="password-toggle-check" type="checkbox">
                           <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="password-toggle-indicator"></span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </label>
                     </div>
                  </div>

                  <button class="btn btn-primary btn-shadow d-block w-100" type="submit"><?php echo e(__('Register')); ?></button>
               </form>
            </div>
         </div>
      </div>
   </div>

   <!-- Navbar Electronics Store-->
   <header class="shadow-sm">
      <!-- Topbar-->
      <div class="topbar topbar-dark bg-dark">
         <div class="container">
            <div>
               <div class="topbar-text text-nowrap d-none d-md-inline-block border-start border-light ps-3">
                 <marquee class="font-weight-bold"  style="color:white; font-size:18px">
                  Toko Bunga Online 24 Jam Terlengkap Dan Pengiriman Seluruh Indonesia, Dapatkan Diskon Dengan Order Online</marquee> 
               </div>
            </div>
            
            <div class="d-none d-md-block ms-3 text-nowrap">             
                  
               <a class="topbar-link ms-3 border-start border-light ps-3 d-none d-md-inline-block" href="">
                  <i class="ci-location mt-n1"></i>Order tracking</a>

            </div>
         </div>
      </div>
      <!-- Remove "navbar-sticky" class to make navigation bar scrollable with the page.-->
      <div class="navbar-sticky bg-light">
         <div class="navbar navbar-expand-lg navbar-light">
            <div class="container"><a class="navbar-brand d-none d-sm-block me-3 flex-shrink-0" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('assets/logo_cv.jfif')); ?>" width="142" alt="Bunda Florist"></a>
               <a class="navbar-brand d-sm-none me-2" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('zilla/img/logo_cv.png')); ?>" width="50" alt="Bunda Florist"></a>
               <!-- Search-->
               <div class="input-group d-none d-lg-flex flex-nowrap mx-4"><i class="ci-search position-absolute top-50 start-0 translate-middle-y ms-3"></i>
                  <input wire:model="search" class="form-control rounded-start w-100" type="text" placeholder="Search for products" aria-label="Search">
                  
               </div>
               <!-- Toolbar-->
               <div class="navbar-toolbar d-flex flex-shrink-0 align-items-center">
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><a class="navbar-tool navbar-stuck-toggler" href="#"><span class="navbar-tool-tooltip">Toggle
                        menu</span>
                     <div class="navbar-tool-icon-box"><i class="navbar-tool-icon ci-menu"></i></div>                    
                  
                  <?php if(auth()->guard()->guest()): ?>
                     </a><a class="navbar-tool ms-1 ms-lg-0 me-n1 me-lg-2" href="#signin-modal" data-bs-toggle="modal">
                     <div class="navbar-tool-icon-box"><i class="navbar-tool-icon ci-user"></i></div>
                     <div class="navbar-tool-text ms-n3"><small style="font-size: 15px">Login</small>My Account</div>
                   </a>
                   
                   <?php else: ?>

                   <div class="navbar-tool dropdown ms-2"><a class="navbar-tool-icon-box border dropdown-toggle"><img src="<?php echo e(asset('zilla/img/marketplace/account/avatar-sm.png')); ?>" width="32" alt="<?php echo e(Auth::user()->name); ?>"></a>
                     <?php if(!empty($pesanan)): ?>
                     <a class="navbar-tool-text ms-n1"><small style="font-size: 15px"><?php echo e(Auth::user()->name); ?> </small> Rp. <?php echo e(number_format($pesanan->total_harga)); ?> </a>
                     <div class="dropdown-menu dropdown-menu-end">
                        <div style="min-width: 14rem;">
                           <h6 class="dropdown-header">Account</h6>
                           <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('history')); ?>"><i class="ci-delivery opacity-60 me-2"></i>History<span class="fs-xs text-muted ms-auto">Rp. <?php echo e(number_format($pesanan->total_harga)); ?></span></a>
                           <div class="dropdown-divider"></div>
                           <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                           document.getElementById('logout-form').submit();"><i class="ci-sign-out opacity-60 me-2"></i><?php echo e(__('Logout')); ?></a>

                           <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                              <?php echo csrf_field(); ?>
                           </form>
                        </div>
                     </div>

                     <?php else: ?>
                     <a class="navbar-tool-text ms-n1"><small style="font-size: 15px"><?php echo e(Auth::user()->name); ?> </small> Pesanan Kosong </a>
                     <div class="dropdown-menu dropdown-menu-end">
                        <div style="min-width: 14rem;">
                           <h6 class="dropdown-header">Account</h6>
                           <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('history')); ?>"><i class="ci-delivery opacity-60 me-2"></i>History<span class="fs-xs text-muted ms-auto">Rp. 0</span></a>
                           <div class="dropdown-divider"></div>
                           <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                           document.getElementById('logout-form').submit();"><i class="ci-sign-out opacity-60 me-2"></i><?php echo e(__('Logout')); ?></a>

                           <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                              <?php echo csrf_field(); ?>
                           </form>
                        </div>
                     </div>
                     <?php endif; ?>
                  </div>

                  <?php endif; ?>
                  <div class="navbar-tool dropdown ms-3">
                     <a class="navbar-tool-icon-box bg-secondary dropdown-toggle" href="<?php echo e(route('keranjang')); ?>">
                        <i class="navbar-tool-icon ci-cart"></i>
                        <?php if($jumlah_pesanan !==0): ?>
                        <span class="navbar-tool-label"><?php echo e($jumlah_pesanan); ?></span>                        
                        <?php endif; ?>
                     </a>
                     <?php $no = 1 ?>
                     <?php if($jumlah_pesanan !== 0): ?>
                     <a class="navbar-tool-text" href="<?php echo e(route('keranjang')); ?>"><small style="font-size: 15px"> Keranjang </small> Anda </a>
                     <?php else: ?>
                     <a class="navbar-tool-text" href="<?php echo e(route('keranjang')); ?>"><small style="font-size: 15px"> Keranjang </small> Kosong </a>
                     <?php endif; ?>
                     <!-- Cart dropdown-->
                     <div class="dropdown-menu dropdown-menu-end">
                        <div class="widget widget-cart px-3 pt-2 pb-3" style="width: 21rem;">
                           <div style="height: 15rem;" data-simplebar data-simplebar-auto-hide="false">
                              <?php $__currentLoopData = $pesanan_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanan_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class=" pb-2 border-bottom">                                 
                                 <div class="d-flex align-items-center pt-2"><a class="d-block flex-shrink-0" href="<?php echo e(route('products')); ?>"><img src="<?php echo e(asset('assets/jersey')); ?>/<?php echo e($pesanan_detail->product->gambar); ?>" width="64" alt="Product"></a>
                                    <div class="ps-2">
                                       <h6 class="widget-product-title"><a href="<?php echo e(route('products')); ?>"> <?php echo e($pesanan_detail->product->nama); ?> </a></h6>
                                       <div class="widget-product-meta"><span class="text-accent me-2"> Rp. <?php echo e(number_format($pesanan_detail->product->harga)); ?> </span><span class="text-muted">x <?php echo e($pesanan_detail->jumlah_pesanan); ?></span>
                                          <button class="btn text-danger" type="button" wire:click="destroy(<?php echo e($pesanan_detail->id); ?>)" aria-label="Remove"><span aria-hidden="true"><i class="ci-trash me-2 fs-base align-middle"></i></span></button>
                                       </div>
                                    </div>
                                 </div>                                     
                              </div>
                              
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                           </div>
                           <div class="d-flex flex-wrap justify-content-between align-items-center py-3">
                              
                              <div class="fs-sm me-2 py-2"><span class="text-muted">Subtotal:</span> 
                              <?php if(!empty($pesanan)): ?>
                              <span>Rp. <?php echo e(number_format($pesanan->total_harga)); ?></span>
                              <?php else: ?>
                              <span>Anda Belum Punya Pesanan</span>                              
                              <?php endif; ?> </div>                             
                              
                           </div>
                           <a class="btn btn-primary btn-sm d-block w-100" href="<?php echo e(route('checkout')); ?>"><i class="ci-card me-2 fs-base align-middle"></i>Checkout</a>
                        </div>
                     </div>
                     
                     
                  </div>
               </div>
            </div>
         </div>
         <div class="navbar navbar-expand-lg navbar-light navbar-stuck-menu mt-n2 pt-0 pb-2">
            <div class="container">
               <div class="collapse navbar-collapse" id="navbarCollapse">
                  <!-- Search-->
                  <div class="input-group d-lg-none my-3"><i class="ci-search position-absolute top-50 start-0 translate-middle-y ms-3"></i>
                     <input class="form-control rounded-start" type="text" placeholder="Search for products">
                  </div>
                  
                  <!-- Primary menu-->
                  <ul class="navbar-nav">
                     <li class="nav-item active"><a class="nav-link" href="<?php echo e(route('home')); ?>"><i class="ci-home"></i> Home </a>
                     </li>

                     <li class="nav-item"><a class="nav-link" href="<?php echo e(route('products')); ?>"><i class="ci-view-grid"></i> Semua Product </a>
                     </li>
                     
                     <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="ci-package"></i> Papan Bunga</a>
                        <ul class="dropdown-menu">                        
                           <?php $__currentLoopData = $ligas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                           <li><a class="dropdown-item " href="<?php echo e(route('products.liga', [Str::slug($liga->slug)])); ?>"> <?php echo e($liga->nama); ?> </a></li>                           
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                     </li>

                     <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="ci-package"></i> Hand Buket</a>
                        <ul class="dropdown-menu">                        
                           <?php $__currentLoopData = $hand_bucket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bucket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <li><a class="dropdown-item " href="<?php echo e(route('products.liga', [Str::slug($bucket->slug)])); ?>"> <?php echo e($bucket->nama); ?> </a></li>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                     </li>

                     <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="ci-package"></i> Krans Duka Cita</a>
                        <ul class="dropdown-menu">                        
                           <?php $__currentLoopData = $krans_dc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <li><a class="dropdown-item " href="<?php echo e(route('products.liga', [Str::slug($dc->slug)])); ?>"> <?php echo e($dc->nama); ?> </a></li>                           
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                     </li>

                     <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="ci-gift"></i> Parcel </a>
                        <ul class="dropdown-menu">                        
                           <?php $__currentLoopData = $parcel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pcl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <li><a class="dropdown-item " href="<?php echo e(route('products.liga', [Str::slug($pcl->slug)])); ?>"> <?php echo e($pcl->nama); ?> </a></li>                           
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                     </li>

                  </ul>
               </div>
            </div>
         </div>
      </div>
   </header>
</div><?php /**PATH C:\laragon\www\tokobunga\resources\views/livewire/navbar.blade.php ENDPATH**/ ?>