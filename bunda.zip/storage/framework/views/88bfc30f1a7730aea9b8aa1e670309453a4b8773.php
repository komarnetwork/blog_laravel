<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">

   <!-- CSRF Token -->
   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

   <title><?php echo $__env->yieldContent('title'); ?> - Bunda Florist</title>

   <!-- SEO Meta Tags-->
   <meta name="description" content="Toko Bunga terpercaya">
   <meta name="keywords" content="bunda florist, toko bunga, toko bunga terpercaya , toko bunga 24 jam, papan bunga, papan bunga murah, karangan bunga, hand buket">
   <meta name="author" content="Createx Studio">

   <!-- Favicon and Touch Icons-->
   <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('zilla/img/favicon/apple-touch-icon.png')); ?>">
   <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('zilla/img/favicon/favicon-32x32.png')); ?>">
   <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('zilla/img/favicon/favicon-16x16')); ?>">
   <link rel="mask-icon" color="#fe6a6a" href="<?php echo e(asset('zilla/img/favicon/safari-pinned-tab.svg')); ?>">
   <meta name="msapplication-TileColor" content="#ffffff">
   <meta name="theme-color" content="#ffffff">
   <meta name="turbolinks-visit-control" content="reload">

   <!-- Scripts -->
   <script src="<?php echo e(asset('js/app.js')); ?>" data-turbolinks-track="reload" defer></script>

   

   <!-- Vendor Styles including: Font Icons, Plugins, etc.-->
   <link rel="stylesheet" media="screen" href="<?php echo e(asset('zilla/css/simplebar.min.css')); ?>" />
   <link rel="stylesheet" media="screen" href="<?php echo e(asset('zilla/vendor/tiny-slider/dist/tiny-slider.css')); ?>" />
   <link rel="stylesheet" media="screen" href="<?php echo e(asset('zilla/css/drift-basic.min.css')); ?>" />
   <link rel="stylesheet" media="screen" href="<?php echo e(asset('zilla/css/lightgallery.min.css')); ?>" />
   <link rel="stylesheet" media="screen" href="<?php echo e(asset('zilla/css/custom.css')); ?>" />
   <!-- Main Theme Styles + Bootstrap-->
   <link rel="stylesheet" media="screen" href="<?php echo e(asset('zilla/css/theme.min.css')); ?>">

   <!-- Fonts -->
   <link rel="dns-prefetch" href="//fonts.gstatic.com">
   <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;700&display=swap" rel="stylesheet">

   

   <!-- Styles -->
   
   

   <?php echo $__env->yieldContent('css'); ?>
   <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body class="handheld-toolbar-enabled">
   <div id="app">
      
      <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('navbar', [])->dom;
} elseif ($_instance->childHasBeenRendered('DDCagyo')) {
    $componentId = $_instance->getRenderedChildComponentId('DDCagyo');
    $componentTag = $_instance->getRenderedChildComponentTagName('DDCagyo');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('DDCagyo');
} else {
    $response = \Livewire\Livewire::mount('navbar', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('DDCagyo', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

      
      <?php echo $__env->yieldContent('content'); ?>

      <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('footer', [])->dom;
} elseif ($_instance->childHasBeenRendered('ljZ0lch')) {
    $componentId = $_instance->getRenderedChildComponentId('ljZ0lch');
    $componentTag = $_instance->getRenderedChildComponentTagName('ljZ0lch');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ljZ0lch');
} else {
    $response = \Livewire\Livewire::mount('footer', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('ljZ0lch', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?></livewire:footer>
      
   </div>

   <?php echo \Livewire\Livewire::scripts(); ?>

   
   
   <!-- Vendor scrits: js libraries and plugins-->
   <script src="<?php echo e(asset('zilla/js/bootstrap.bundle.min.js')); ?>"></script>
   <script src="<?php echo e(asset('zilla/js/simplebar.min.js')); ?>"></script>
   <script src="<?php echo e(asset('zilla/vendor/tiny-slider/dist/min/tiny-slider.js')); ?>"></script>
   <script src="<?php echo e(asset('zilla/js/smooth-scroll.polyfills.min.js')); ?>"></script>
   <script src="<?php echo e(asset('zilla/vendor/drift-zoom/dist/Drift.min.js')); ?>"></script>
   <script src="<?php echo e(asset('zilla/js/lightgallery.min.js')); ?>"></script>
   <script src="<?php echo e(asset('zilla/js/popper.min.js')); ?>"></script>
   
   <!-- Main theme script-->
   <script src="<?php echo e(asset('zilla/js/theme.min.js')); ?>"></script>

   <script type="text/javascript">
      function getWA() {
          var win = windows.open('https://api.whatsapp.com/send/?phone=628111961139&text=Halo+Bunda+Florist%2C+Saya+Ingin+Order+Bunga&app_absent=0', '_blank');
         win.focus();
      }
      
  </script>

  
   <?php echo $__env->yieldContent('javascript'); ?>
   
</body>

</html><?php /**PATH C:\laragon\www\tokobunga\resources\views/layouts/app.blade.php ENDPATH**/ ?>