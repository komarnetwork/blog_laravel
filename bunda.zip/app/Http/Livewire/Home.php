<?php

namespace App\Http\Livewire;

use App\Liga;
use App\Product;
use Livewire\Component;
use Livewire\WithPagination;

class Home extends Component
{
    

    public function render()
    {
       
        return view('livewire.home', [
            // 'products' => Product::with('krans', 'bucket', 'papan_bunga')->get(),
            'products' => Product::take(7)->get(),
           
            'ligas' => Liga::all(),
            'bunga_tangan' => Liga::find([4]),
            'krans' => Liga::find([6]),
            'bucket' => Liga::find([4]),
            'papan_bunga' => Liga::find([1])

        ]);
    }
}
