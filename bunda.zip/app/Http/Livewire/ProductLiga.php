<?php

namespace App\Http\Livewire;

use App\Liga;
use App\Product;
use Livewire\Component;
use Livewire\WithPagination;

class ProductLiga extends Component
{

    use WithPagination;

    public $search, $liga, $slug;

    protected $updateQueryString = ['search'];

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function mount($slug)
    {
        // $ligaDetail = Liga::find($ligaId);
        $ligaDetail = Liga::where('slug' ,$slug)->first();

        if($ligaDetail) {
            $this->liga = $ligaDetail;
        }
    }

    public function render()
    {
        if($this->search) {
            $products = Product::where('liga_id', $this->liga->id)->where('nama', 'like', '%'.$this->search.'%')->paginate(8);
        }else {
            $products = Product::where('liga_id', $this->liga->id)->paginate(8);
        }

        return view('livewire.product-liga', [
            'products' => $products,
            'title' => $this->liga->nama
        ]);
    }
}
