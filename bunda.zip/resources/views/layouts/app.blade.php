<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">

   <!-- CSRF Token -->
   <meta name="csrf-token" content="{{ csrf_token() }}">

   <title>@yield('title') - Bunda Florist</title>

   <!-- SEO Meta Tags-->
   <meta name="description" content="Toko Bunga terpercaya">
   <meta name="keywords" content="bunda florist, toko bunga, toko bunga terpercaya , toko bunga 24 jam, papan bunga, papan bunga murah, karangan bunga, hand buket">
   <meta name="author" content="Createx Studio">

   <!-- Favicon and Touch Icons-->
   <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('zilla/img/favicon/apple-touch-icon.png') }}">
   <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('zilla/img/favicon/favicon-32x32.png') }}">
   <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('zilla/img/favicon/favicon-16x16') }}">
   <link rel="mask-icon" color="#fe6a6a" href="{{ asset('zilla/img/favicon/safari-pinned-tab.svg') }}">
   <meta name="msapplication-TileColor" content="#ffffff">
   <meta name="theme-color" content="#ffffff">
   <meta name="turbolinks-visit-control" content="reload">

   <!-- Scripts -->
   <script src="{{ asset('js/app.js') }}" data-turbolinks-track="reload" defer></script>

   

   <!-- Vendor Styles including: Font Icons, Plugins, etc.-->
   <link rel="stylesheet" media="screen" href="{{ asset('zilla/css/simplebar.min.css') }}" />
   <link rel="stylesheet" media="screen" href="{{ asset('zilla/vendor/tiny-slider/dist/tiny-slider.css') }}" />
   <link rel="stylesheet" media="screen" href="{{ asset('zilla/css/drift-basic.min.css') }}" />
   <link rel="stylesheet" media="screen" href="{{ asset('zilla/css/lightgallery.min.css') }}" />
   <link rel="stylesheet" media="screen" href="{{ asset('zilla/css/custom.css') }}" />
   <!-- Main Theme Styles + Bootstrap-->
   <link rel="stylesheet" media="screen" href="{{ asset('zilla/css/theme.min.css') }}">

   <!-- Fonts -->
   <link rel="dns-prefetch" href="//fonts.gstatic.com">
   <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;700&display=swap" rel="stylesheet">

   {{-- <link href="{{ asset('fontawesome/css/all.min.css') }}" rel="stylesheet"> --}}

   <!-- Styles -->
   {{-- <link href="{{ asset('css/app.css') }}" rel="stylesheet"> --}}
   {{-- <link href="{{ asset('css/custom.css') }}" rel="stylesheet"> --}}

   @yield('css')
   @livewireStyles
</head>

<body class="handheld-toolbar-enabled">
   <div id="app">
      
      <livewire:navbar />

      {{-- <main class="py-4"> --}}
      @yield('content')

      <livewire:footer></livewire:footer>
      {{-- </main> --}}
   </div>

   @livewireScripts
   {{-- Js Livewire --}}
   
   <!-- Vendor scrits: js libraries and plugins-->
   <script src="{{ asset('zilla/js/bootstrap.bundle.min.js') }}"></script>
   <script src="{{ asset('zilla/js/simplebar.min.js') }}"></script>
   <script src="{{ asset('zilla/vendor/tiny-slider/dist/min/tiny-slider.js') }}"></script>
   <script src="{{ asset('zilla/js/smooth-scroll.polyfills.min.js') }}"></script>
   <script src="{{ asset('zilla/vendor/drift-zoom/dist/Drift.min.js') }}"></script>
   <script src="{{ asset('zilla/js/lightgallery.min.js') }}"></script>
   <script src="{{ asset('zilla/js/popper.min.js') }}"></script>
   
   <!-- Main theme script-->
   <script src="{{ asset('zilla/js/theme.min.js') }}"></script>

   <script type="text/javascript">
      function getWA() {
          var win = windows.open('https://api.whatsapp.com/send/?phone=628111961139&text=Halo+Bunda+Florist%2C+Saya+Ingin+Order+Bunga&app_absent=0', '_blank');
         win.focus();
      }
      
  </script>

  
   @yield('javascript')
   
</body>

</html>