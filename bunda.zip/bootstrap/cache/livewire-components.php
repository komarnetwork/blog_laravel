<?php return array (
  'checkout' => 'App\\Http\\Livewire\\Checkout',
  'footer' => 'App\\Http\\Livewire\\Footer',
  'history' => 'App\\Http\\Livewire\\History',
  'home' => 'App\\Http\\Livewire\\Home',
  'keranjang' => 'App\\Http\\Livewire\\Keranjang',
  'navbar' => 'App\\Http\\Livewire\\Navbar',
  'product-detail' => 'App\\Http\\Livewire\\ProductDetail',
  'product-index' => 'App\\Http\\Livewire\\ProductIndex',
  'product-liga' => 'App\\Http\\Livewire\\ProductLiga',
);